<?php 
/**
 * Templates Name: Elementor
 * Widget: Search Form
 */
    ?>
        <div <?php echo trim($this->get_render_attribute_string('wrapper')); ?>>
            <?php $this->render_search_form(); ?>
        </div>
    <?php
?>