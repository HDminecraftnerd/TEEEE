<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package WordPress
 * @subpackage Besa
 * @since Besa 1.0
 */
/*

*Template Name: 404 Page
*/
get_header();

?>

<section id="main-container" class=" container inner" style="padding: 0px;">
	<div id="main-content" class="main-page page-404" style="max-width: 100%;padding: 0px;">
		<section class="error-404 text-center">
			<h1 style="margin:0px !important;">
				<span style="font-size:500px;color:#FF6666;font-weight: 300; letter-spacing: 100px;">4</span>
				<span style="font-size:500px;color:#FFD845;font-weight: 300; letter-spacing: 100px;">0</span>
				<span style="font-size:500px;color:#6F77F4;font-weight: 300; letter-spacing: 100px;">4</span>
			</h1>
			<h2 style="color: #3a3a3a !important; font-size: 24px;">Oops! Looks Like You Lost Your Way. <a href="<?php echo site_url('/'); ?>" style="text-decoration: underline;">Go to Home Page.</a></h2>
		</section><!-- .error-404 -->
	</div>
</section>
<style>
	#content{ 
		background-color:#FBFBFB; 
		border-style: solid;
		border-width: 50px 50px 0px 50px;
		border-color: #ffffff;
		transition: background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;
		padding: 0px 50px 50px 50px;
		z-index: 15;
	}
	@media only screen and (max-width: 768px) {
		#main-content span {
			font-size:120px !important;
			letter-spacing: 1px !important;  
		}
		#main-content{
			margin-top:100px;
		}
	}
</style>

<?php get_footer(); ?>