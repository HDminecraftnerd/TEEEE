<?php
/**
 * The template for displaying all single posts.
 *
 * @package woostify
 */

get_header();

do_action( 'woostify_theme_single' );

get_footer();
