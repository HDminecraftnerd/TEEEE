jQuery(document).ready(() => {

 	var form = $('form.register'); 

    $( '.tc_pp_check_box', form ).on( 'click', function() {
    	var chk_value = $( this ).val();


    	 

		if( $('.tc_check_box').length > 0 )
			if( $( this ).prop( "checked" )  && ( $('.tc_check_box').is(":hidden") || $('.tc_check_box').prop( "checked" ) )  ) {
	            $( 'input[name=register]' ).removeAttr( 'disabled' );
	            $( 'button[name=register]' ).removeAttr( 'disabled' );
	            $( 'input[name=dokan_migration]' ).removeAttr( 'disabled' );
			} else {
				$( 'input[name=register]' ).attr( 'disabled', 'disabled' );
				$( 'button[name=register]' ).attr( 'disabled', 'disabled' );
				$( 'input[name=dokan_migration]' ).attr( 'disabled', 'disabled' );	
			}
		else {

			if( $( this ).prop( "checked" ) ) {
	            $( 'input[name=register]' ).removeAttr( 'disabled' );
	            $( 'button[name=register]' ).removeAttr( 'disabled' );
	            $( 'input[name=dokan_migration]' ).removeAttr( 'disabled' );
			} else {
	            $( 'input[name=register]' ).attr( 'disabled', 'disabled' );
	            $( 'button[name=register]' ).attr( 'disabled', 'disabled' );
	            $( 'input[name=dokan_migration]' ).attr( 'disabled', 'disabled' );
			}


		}

    });


});

jQuery(document).on('shown.bs.tab', 'a[data-toggle="tab"]', function (e) {
	if( $('.tc_pp_check_box').length > 0 ){
        $( 'input[name=dokan_migration]' ).attr( 'disabled', 'disabled' );
        $( 'button[name=register]' ).attr( 'disabled', 'disabled' );
	}   
})