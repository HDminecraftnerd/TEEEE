<?php
/**
 * Dokan Settings Address form Template
 *
 * @since 2.4
 *
 * @package dokan
 */
$countries       = new WC_Countries();
$states_places   = new WC_States_Places();
$states_places_c = $states_places->get_places();
$default_state   = ( isset( $states_places_c[$countries->get_base_country()] ) ? $states_places_c[$countries->get_base_country()] : '' );

$address         = isset( $profile_info['address'] ) ? $profile_info['address'] : '';
$address_street1 = isset( $profile_info['address']['street_1'] ) ? $profile_info['address']['street_1'] : '';
$address_street2 = isset( $profile_info['address']['street_2'] ) ? $profile_info['address']['street_2'] : '';
$address_city    = isset( $profile_info['address']['city'] ) ? $profile_info['address']['city'] : '';
$address_zip     = isset( $profile_info['address']['zip'] ) ? $profile_info['address']['zip'] : '';
$address_country = isset( $profile_info['address']['country'] ) ? $profile_info['address']['country'] : $countries->get_base_country();
$address_state   = isset( $profile_info['address']['state'] ) ? $profile_info['address']['state'] : $default_state;
$address_country = "LK";
?>

<input type="hidden" id="dokan_selected_country" value="<?php echo esc_attr( $address_country )?>" />
<input type="hidden" id="dokan_selected_state" value="<?php echo esc_attr( $address_state ); ?>" />
<div class="dokan-form-group">
    <label class="dokan-w3 dokan-control-label" for="setting_address"><?php esc_html_e( 'Address', 'dokan-lite' ); ?></label>

    <div class="dokan-w5 dokan-text-left dokan-address-fields">
        <?php if ( $seller_address_fields['street_1'] ) { ?>
            <div class="dokan-form-group">
                <label class="dokan-w3 control-label" for="dokan_address[street_1]"><?php esc_html_e( 'Street ', 'dokan-lite' ); ?>
                    <?php
                    $required_attr = '';
                    if ( $seller_address_fields['street_1']['required'] ) {
                        $required_attr = 'required'; ?>
                        <span class="required"> *</span>
                    <?php } ?>
                </label>
                <input <?php echo esc_attr( $required_attr ); ?> <?php echo esc_attr( $disabled ) ?> id="dokan_address[street_1]" value="<?php echo esc_attr( $address_street1 ); ?>" name="dokan_address[street_1]" placeholder="<?php esc_attr_e( 'Street address' , 'dokan-lite' ) ?>" class="dokan-form-control input-md" type="text">
            </div>
        <?php }
        if ( $seller_address_fields['street_2'] ) { ?>
            <div class="dokan-form-group">
                <label class="dokan-w3 control-label" for="dokan_address[street_2]"><?php esc_html_e( 'Street 2', 'dokan-lite' ); ?>
                    <?php
                    $required_attr = '';
                    if ( $seller_address_fields['street_2']['required'] ) {
                        $required_attr = 'required'; ?>
                        <span class="required"> *</span>
                    <?php } ?>
                </label>
                <input <?php echo esc_attr( $required_attr ); ?> <?php echo esc_attr( $disabled ) ?> id="dokan_address[street_2]" value="<?php echo esc_attr( $address_street2 ); ?>" name="dokan_address[street_2]" placeholder="<?php esc_attr_e( 'Apartment, suite, unit etc. (optional)' , 'dokan-lite' ) ?>" class="dokan-form-control input-md" type="text">
            </div>
        <?php } ?>
        <?php if ( $seller_address_fields['country'] ) {
            $country_obj   = new WC_Countries();
            $countries     = $country_obj->countries;
            $states        = $country_obj->states;
        ?>
            <div class="dokan-form-group" style="display: none;">
                <label class="control-label" for="dokan_address[country]"><?php esc_html_e( 'Country ', 'dokan-lite' ); ?>
                    <?php
                    $required_attr = '';
                    if ( $seller_address_fields['country']['required'] ) {
                        $required_attr = 'required'; ?>
                        <span class="required"> *</span>
                    <?php } ?>
                </label>
				<span class="woocommerce-input-wrapper">
					<strong>Sri Lanka</strong>
					<input type="hidden" name="dokan_address[country]" id="dokan_address_country" value="<?php echo $address_country; ?>" autocomplete="country" class="country_to_state dokan-form-control" readonly="readonly">
				</span>
                <!--select < ?php echo esc_attr( $required_attr ); ?> < ?php echo esc_attr( $disabled ) ?> name="dokan_address[country]" class="country_to_state dokan-form-control dokan-select2" id="dokan_address_country">
                    < ?php dokan_country_dropdown( $countries, $address_country, false ); ?>
                </select-->
            </div>
        <?php }

        $seller_address_fields['state']['required'] = 1;
        $seller_address_fields['city']['required'] = 1;

        if ( $seller_address_fields ) {
            $address_state_class = '';
            $is_input            = false;
            $no_states           = false;

            if ( isset( $states[$address_country] ) ) {
                if ( empty( $states[$address_country] ) ) {
                    $address_state_class = 'dokan-hide';
                    $no_states           = true;
                }
            } else {
                $is_input = true;
            }
        ?>
            <div id="dokan-states-box" class="dokan-form-group" style="display: block">
                <label class="dokan-w3 control-label" for="dokan_address[state]"><?php esc_html_e( 'State ', 'dokan-lite' ); ?>
                    <?php
                    $required_attr = '';
                    if ( $seller_address_fields['state']['required'] ) {
                        $required_attr = 'required'; ?>
                        <span class="required"> *</span>
                    <?php } ?>
                </label>

            <?php if ( $is_input ) {
                    $required_attr = '';
                    if ( $seller_address_fields['state']['required'] ) {
                        $required_attr = 'required';
                    }
                    ?>

                <input <?php echo esc_attr( $required_attr ); ?> <?php echo esc_attr( $disabled ) ?> name="dokan_address[state]" class="dokan-form-control <?php echo esc_attr( $address_state_class ) ?>" id="dokan_address_state" value="<?php echo esc_attr( $address_state ) ?>"/>
            <?php } else {
                    $required_attr = '';
                    if ( $seller_address_fields['state']['required'] ) {
                        $required_attr = 'required';
                    }
                ?>
                <select <?php echo esc_attr( $required_attr ); ?> <?php echo esc_attr( $disabled ) ?> name="dokan_address[state]" class="dokan-form-control state_select dokan-select2" id="dokan_address_state">
                    <?php dokan_state_dropdown( $states[$address_country], $address_state ) ?>
                </select>
            <?php } ?>
            </div>
        <?php } ?>
		<?php if ( $seller_address_fields ) {
			$states_places = new WC_States_Places();
            $is_input      = false;
			if ( $country = $states_places->get_places() ) {
				if( $country && is_array( $country ) && isset( $country[$address_country] ) && isset( $country[$address_country][$address_state] ) ) {
					$cities = array_combine( $country[$address_country][$address_state], $country[$address_country][$address_state] );
				} else {
					$cities = [];
				}
			} else {
				$is_input = true;
			}
        ?>
            <div class="dokan-from-group">
                <?php if ( $seller_address_fields['city'] ) { ?>
                    <div class="dokan-form-group dokan-w6 dokan-left dokan-right-margin-30">
                        <label class="control-label" for="dokan_address_city"><?php esc_html_e( 'City', 'dokan-lite' ); ?>
                            <?php
                            $required_attr = '';
                            if ( $seller_address_fields['city']['required'] ) {
                                $required_attr = 'required'; ?>
                                <span class="required">*</span>
                            <?php } ?>
                        </label>
						<?php if( $is_input ) : ?>
                        	<input <?php echo esc_attr( $required_attr ); ?> <?php echo esc_attr( $disabled ); ?> id="dokan_address_city" name="dokan_address[city]" class="dokan-form-control input-md" value="<?php echo esc_attr( $address_city ); ?>" placeholder="<?php esc_attr_e( 'Town / City' , 'dokan-lite' ); ?>" type="text">
						<?php else : ?>
							<select <?php echo esc_attr( $required_attr ); ?> <?php echo esc_attr( $disabled ) ?> id="dokan_address_city" name="dokan_address[city]" class="dokan-form-control dokan-select2" autocomplete="address-level2" >
								<?php dokan_state_dropdown( $cities, $address_city ) ?>
							</select>
						<?php endif; ?>
                    </div>
                <?php }
                if ( $seller_address_fields['zip'] ) { ?>
                    <div class="dokan-form-group dokan-w5 dokan-left">
                        <label class="control-label" for="shop-zip"><?php esc_html_e( 'Post/ZIP Code', 'dokan-lite' ); ?>
                            <?php
                            $required_attr = '';
                            if ( $seller_address_fields['zip']['required'] ) {
                                $required_attr = 'required'; ?>
                                <span class="required"> *</span>
                            <?php } ?>
                        </label>
                        <input <?php echo esc_attr( $required_attr ); ?> <?php echo esc_attr( $disabled ) ?> id="shop-zip" value="<?php echo esc_attr( $address_zip ); ?>" name="dokan_address[zip]" placeholder="<?php esc_attr_e( 'Postcode / Zip' , 'dokan-lite' ) ?>" class="dokan-form-control input-md" readonly type="text">
                    </div>
                <?php } ?>
                <div class="dokan-clearfix"></div>
            </div>
        <?php } ?>
    </div>
</div>
