<?php
/**
 * @version    1.0
 * @package    besa
 * @author     Thembay Team <support@thembay.com>
 * @copyright  Copyright (C) 2019 Thembay.com. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: https://thembay.com
 */

add_action('wp_enqueue_scripts', 'besa_child_enqueue_styles', 10000);
function besa_child_enqueue_styles()
{
    $parent_style = 'besa-style';
    wp_enqueue_style($parent_style, get_template_directory_uri() . '/style.css');
    wp_enqueue_style('besa-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array($parent_style),
        wp_get_theme()->get('Version')
    );
	wp_enqueue_script( 'customize-js', get_stylesheet_directory_uri() . '/js/customize.js', array( 'jquery' ),'',true );
}

add_action('wp_footer', 'import_export_xml_button');
function import_export_xml_button()
{
    echo "<script>
                jQuery(document).ready(function(){
                    jQuery('input[name=\"import_xml\"]').removeAttr('class').attr('class', 'dokan-btn dokan-btn-theme');
                    jQuery('input[name=\"export_xml\"]').removeAttr('class').attr('class', 'dokan-btn dokan-btn-theme');
                    // jQuery('input[name=\"dokan_migration\"]').css('background-color', '#fa4f26').css('color', '#fff');
                });
            </script>";
}

if ( class_exists( 'WC_States_Places' ) ) {

    class WC_States_Places_Besa extends WC_States_Places {

        /**
         * Construct class
         */
        public function __construct() {
            add_action( 'wp_enqueue_scripts',           array( $this, 'add_scripts' ) );
            add_action( 'wp_footer',                    array( $this, 'add_script' ) );
            add_action( 'woocommerce_created_customer', array( $this, 'save_vendor_info' ), 10, 2 );
            add_action( 'init',                         array( $this, 'dokan_store_profile_saved' ), 10, 2 );
        }

        /**
         * Load scripts
         */
        public function add_scripts() {
            if (has_shortcode( get_the_content(), 'dokan-vendor-registration' ) || has_shortcode( get_the_content(), 'dokan-dashboard' ) || has_shortcode( get_the_content(), 'woocommerce_my_account' ) ) {
                $city_select_path = parent::get_plugin_url() . 'js/place-select.js';
                wp_enqueue_script( 'wc-city-select', $city_select_path, [ 'jquery', 'woocommerce' ], '1.0', true );
                $places = json_encode( parent::get_places() );
                wp_localize_script( 'wc-city-select', 'wc_city_select_params', array(
                    'cities'                => $places,
                    'i18n_select_city_text' => esc_attr__( 'Select an option&hellip;', 'woocommerce' )
                ) );
                wp_add_inline_script( 'wc-city-select', $this->add_script(), 'after' );
            }
        }

        /**
         * Custom
         */
        public function add_script() {
            ob_start();
            ?>
            jQuery( function($) {
            if ( typeof wc_city_select_params === 'undefined' ) {
            return false;
            }

            var cities_json = wc_city_select_params.cities.replace( /&quot;/g, '"' );
            var cities = $.parseJSON( cities_json );

            $('body')
            .on( 'change', '#dokan_address_state', function() {
            var form        = $( this ).closest( 'form' ),
            country     = form.find( '#dokan_address_country' ).val(),
            $citybox    = form.find( '#dokan_address_city' ),
            state       = $( this ).val();

            var cities_list = cities[country][state].sort();
            if ( cities_list ) {
            $citybox.empty();
            $.each( cities_list, function( key, value ) {
            $citybox.append( '<option value="' + value + '">' + value + '</option>' );
            });
            $citybox.trigger('change.select2');
            form.find('#dokan_address_city').trigger('change');
            } else {

            }
            })
            .on('change', "#dokan_address_city", function(evt) {
            var city   = evt.target.value,
            zip    = $(this).closest( 'form' ).find('#shop-zip'),
            values = {
                "Colombo 01" : "00100",
                "Colombo 02" : "00200",
                "Colombo 03" : "00300",
                "Colombo 04" : "00400",
                "Colombo 05" : "00500",
                "Colombo 06" : "00600",
                "Colombo 07" : "00700",
                "Colombo 08" : "00800",
                "Colombo 09" : "00900",
                "Colombo 10" : "01000",
                "Colombo 11" : "01100",
                "Colombo 12" : "01200",
                "Colombo 13" : "01300",
                "Colombo 14" : "01400",
                "Colombo 15" : "01500",
                "Biyagama" : "11650",
                "Biyagama IPZ" : "11672",
                "Ekala" : "11380",
                "Kelaniya" : "11600",
                "Malwana" : "11670",
                "Pethiyagoda" : "11043",
                "Ragama" : "11010",
                "Seeduwa" : "11410",
                "Wattala" : "11300",
                "Attanagalla" : "11120",
                "Batuwatta" : "11011",
                "Bemmulla" : "11040",
                "Bollete" : "11024",
                "Bopagama" : "11134",
                "Buthpitiya" : "11720",
                "Dagonna" : "11524",
                "Debahera" : "11889",
                "Delgoda" : "11700",
                "Delwagura" : "11228",
                "Demalagama" : "11692",
                "Demanhandiya" : "11270",
                "Dewalapola" : "11102",
                "Dompe" : "11680",
                "Essella" : "11108",
                "Gampaha" : "11000",
                "Ganemulla" : "11020",
                "Heiyanrhuduwa" : "11618",
                "Henegama" : "11715",
                "Hinatiyana Madawala" : "11568",
                "Hiswella" : "11734",
                "Horampella" : "11564",
                "Hunumulla" : "11262",
                "Ihala Madampella" : "11265",
                "Imbulgoda" : "11856",
                "Ja-Ela" : "11350",
                "Kadawatha" : "11850",
                "Kahathuduwa Kahatowita" : "11144",
                "Kalagedihena" : "11875",
                "Kaluaggala" : "11224",
                "Kandana" : "11320",
                "Kapugoda" : "10662",
                "Katunayake" : "11450",
                "Katunayake Air Force Camp" : "11440",
                "Kimbulapitiya" : "11522",
                "Kirindiwela" : "11730",
                "Kirulapone Kitalawalana" : "11206",
                "Kitulwala" : "11242",
                "Kumbaloluwa" : "11105",
                "Mabodala" : "11114",
                "Madelgamuwa" : "11033",
                "Makewita" : "11358",
                "Makola" : "11640",
                "Mandawala" : "11061",
                "Minuwangoda" : "11550",
                "Mudungoda" : "11056",
                "Naranwala" : "11063",
                "Nawana" : "11222",
                "Nedungamuwa" : "11066",
                "Nikahetikanda" : "11128",
                "Nittambuwa" : "11880",
                "Nivandama" : "11354",
                "Pamunugama" : "11370",
                "Pamunuwatta" : "11214",
                "Peliyagoda" : "11830",
                "Pepiliyawala" : "11741",
                "Polpithimukulana" : "11324",
                "Pugoda" : "10660",
                "Raddolugama" : "11400",
                "Rukmale" : "11129",
                "Siyambalape" : "11607",
                "Talahena" : "11504",
                "Thimbirigaskatuwa" : "11532",
                "Udugampola" : "11030",
                "Athurugiriya" : "10150",
                "Battaramulla" : "10120",
                "Bokalagama" : "11216",
                "Boralesgamuwa" : "10290",
                "Dehiwala" : "10350",
                "Deltara" : "10302",
                "Hiripitiya" : "10232",
                "Hokandara" : "10118",
                "Kaduwela" : "10640",
                "Kiriwattuduwa" : "10208",
                "Kolonnawa" : "10600",
                "Madapatha" : "10306",
                "Maharagama" : "10280",
                "Malabe" : "10115",
                "Moratuwa" : "10400",
                "Mount Lavinia" : "10370",
                "Mulleriyawa New Town" : "10620",
                "Nugegoda" : "10250",
                "Pannipitiya" : "10230",
                "Piliyandala" : "10300",
                "Homagama" : "10200",
                "Pitipana Homagama" : "10206",
                "Siddamulla" : "10304",
                "Sri Jayawardenapura" : "10100",
                "Talawatugoda" : "10116",
                "Akarawita" : "10732",
                "Mullegama" : "10202",
                "Rajagiriya" : "10107",
                "Ratmalana" : "10390",
                "Panadura" : "12500",
            };
            if( values[city] ) {
            zip.val(values[city]);
            } else {
            zip.val('');
            }
            });
            });
            <?php
            $script = ob_get_contents();
            ob_end_clean();
            return $script;
        }
        
        public function get_places( $type = 'country', $default = true ) {
            $countries_list = new WC_Countries();
            $base_country   = $countries_list->get_base_country();
            switch( $type ) {
                case 'country':
                    if ( $default == true ) {
                        return $base_country;
                    } else {
                        return $countries_list->countries;
                    }
                    break;
                case 'state':
                    if ( $default == true ) {
                        if ( isset( $countries_list->states[$base_country] ) ) {
                            return key( $countries_list->states[$base_country] );
                        }
                        return '';
                    } else {
                        if ( isset( $countries_list->states[$base_country] ) ) {
                            return $countries_list->states[$base_country];
                        }
                        return $countries_list->states;
                    }
                    break;
                case 'city':
                    $states_places = new WC_States_Places();
                    $country       = $states_places->get_places();
                    $base_state    = isset( $countries_list->states[$base_country] ) ? key( $countries_list->states[$base_country] ) : '';
                    if ( $default == true ) {
                        if( isset( $country[$base_country] ) && isset( $country[$base_country][$base_state] ) && isset( $country[$base_country][$base_state][0] ) ) {
                            return $country[$base_country][$base_state][0];
                        }
                        return '';
                    } else {
                        if( isset( $country[$base_country] ) && isset( $country[$base_country][$base_state] ) ) {
                            return array_combine( $country[$base_country][$base_state], $country[$base_country][$base_state] );
                        }
                        return [];
                    }
                    break;
            }
        }

        public function save_vendor_info( $user_id, $data ) {
            $post_data = wp_unslash( $_POST ); // WPCS: CSRF ok.
            if ( ! isset( $data['role'] ) || $data['role'] != 'seller' ) {
                return;
            }

            //$social_profiles = array();

            foreach ( dokan_get_social_profile_fields() as $key => $item ) {
                $social_profiles[$key] = '';
            }

            $dokan_settings = array(
                'store_name'     => sanitize_text_field( wp_unslash( $post_data['shopname'] ) ),
                'social'         => $social_profiles,
                'payment'        => array(),
                'phone'          => sanitize_text_field( wp_unslash( $post_data['phone'] ) ),
                'show_email'     => 'no',
                'location'       => '',
                'find_address'   => '',
                'dokan_category' => '',
                'banner'         => 0,
            );

            // Intially add values on profile completion progress bar
            $dokan_settings['profile_completion']['store_name']     = 10;
            $dokan_settings['profile_completion']['phone']          = 10;
            $dokan_settings['profile_completion']['next_todo']      = 'banner_val';
            $dokan_settings['profile_completion']['progress']       = 20;
            $dokan_settings['profile_completion']['progress_vals']  = array(
                'banner_val'            => 15,
                'profile_picture_val'   => 15,
                'store_name_val'        => 10,
                'address_val'           => 10,
                'phone_val'             => 10,
                'map_val'               => 15,
                'payment_method_val'    => 15,
                'social_val' => array(
                    'fb'        => 2,
                    'gplus'     => 2,
                    'twitter'   => 2,
                    'youtube'   => 2,
                    'linkedin'  => 2,
                ),
            );
            $dokan_settings['address'] = [
                'country' => esc_html( $post_data['country'] ),
                'state'   => esc_html( $post_data['state'] ),
                'city'    => esc_html( $post_data['city'] ),
                'zip'     => esc_html( $post_data['zip'] ),
            ];

            update_user_meta( $user_id, 'dokan_profile_settings', $dokan_settings );
            update_user_meta( $user_id, 'dokan_store_name', $dokan_settings['store_name'] );
            update_user_meta( $user_id, 'billing_country',  esc_html( $post_data['country'] ) );
            update_user_meta( $user_id, 'billing_state',    esc_html( $post_data['state'] ) );
            update_user_meta( $user_id, 'billing_city',     esc_html( $post_data['city'] ) );
            update_user_meta( $user_id, 'billing_postcode', esc_html( $post_data['zip'] ) );
            update_user_meta( $user_id, 'billing_phone',    esc_html( $post_data['phone'] ) );

            do_action( 'dokan_new_seller_created', $user_id, $dokan_settings );

        }


        public function dokan_store_profile_saved() {
            if ( isset( $_POST['_wp_http_referer'] ) && $_POST['_wp_http_referer'] == '/dashboard/settings/store/' && isset( $_POST['dokan_address'] ) ) {
                $store_id   = dokan_get_current_user_id();
                $post_data  = wp_unslash( $_POST );
                $store_data = get_user_meta( $store_id, 'dokan_profile_settings', true );
                if ( !$store_data ) {
                    $store_data = [];
                }

                $store_data = array(
                    'store_name'     => sanitize_text_field( wp_unslash( $post_data['dokan_store_name'] ) ),
                    'phone'          => sanitize_text_field( wp_unslash( $post_data['setting_phone'] ) ),
                    'show_email'     => sanitize_text_field( wp_unslash( $post_data['setting_show_email'] ) ),
                    'find_address'   => sanitize_text_field( wp_unslash( $post_data['setting_phone'] ) ),
                    'dokan_category' => $post_data['dokan_store_categories'],
                    'banner'         => sanitize_text_field( wp_unslash( $post_data['dokan_banner'] ) ),
                );
                $store_data['address'] = [
                    'street_1' => esc_html( $post_data['dokan_address']['street_1'] ),
                    'street_2' => esc_html( $post_data['dokan_address']['street_2'] ),
                    'country'  => esc_html( $post_data['dokan_address']['country'] ),
                    'state'    => esc_html( $post_data['dokan_address']['state'] ),
                    'city'     => esc_html( $post_data['dokan_address']['city'] ),
                    'zip'      => esc_html( $post_data['dokan_address']['zip'] ),
                ];
                update_user_meta( $store_id, 'dokan_store_name', $store_data['store_name'] );
                update_user_meta( $store_id, 'dokan_profile_settings', $store_data );

                // echo '<pre>';
                // print_r( $store_data );
                // print_r( $post_data );
                // echo '</pre>';
                // wp_die();
            }
        }
    }
    $placess = new WC_States_Places_Besa();
}

/**
 * Use the Description from Global Setting, only if the description is missing in the Post metabox
 */
add_action( 'rank_math/frontend/description', function( $description ) {
    global $post;
    $desc = RankMath\Helper::get_settings( "titles.pt_{$post->post_type}_description" );
    if ( $desc ) {
        return RankMath\Helper::replace_vars( $desc, $post );
    }

    return $description;
});

/**
 * From Dokan Team - To edit vendor support tickets to Support tickets and change no vendor found.
 */

add_action('wp_footer', 'change_my_account_page_strings');
function change_my_account_page_strings(){
    echo "
            <script>
                jQuery(document).ready(function(){
                    jQuery('.woocommerce-account .woocommerce-MyAccount-navigation-link--support-tickets').html('<a href=\"https://dokanpro.local/my-account/support-tickets/\">Support Tickets</a>');
                    jQuery('.woocommerce-account .seller-listing-content').html('<p class=\"dokan-error\"><a href=\"https://www.gift.lk/gifters/\">You\'re not following any vendor!!</a></p>');
                })
            </script>
        ";
}


/**
 * Change Dokan vendor Setup-wizard text
 */

class Dokan_Setup_Wizard_Override extends Dokan_Seller_Setup_Wizard {

    /**
     * Introduction step.
     */
    public function dokan_setup_introduction() {
        $dashboard_url = dokan_get_navigation_url();
        ?>
        <h1><?php esc_attr_e( 'Welcome to Gift.lk', 'dokan-lite' ); ?></h1>
        <p><?php echo wp_kses( __( 'Thank you for choosing Gift.lk to power your online sales! This quick setup wizard will help you configure the basic settings. <strong>It’s completely optional and shouldn’t take longer than a minute.</strong>', 'dokan-lite' ), [ 'strong' => [] ] ); ?></p>
        <p><?php esc_attr_e( 'No time right now? You can skip and return to the Store! At a convenient time, you can go to your dashboard to complete the setup.', 'dokan-lite' ); ?></p>
        <p class="wc-setup-actions step">
            <a href="<?php echo esc_url( $this->get_next_step_link() ); ?>" class="button-primary button button-large button-next lets-go-btn dokan-btn-theme"><?php esc_attr_e( 'Let\'s Go!', 'dokan-lite' ); ?></a>
            <a href="<?php echo esc_url( $dashboard_url ); ?>" class="button button-large not-right-now-btn dokan-btn-theme"><?php esc_attr_e( 'Not right now', 'dokan-lite' ); ?></a>
        </p>
        <?php
        do_action( 'dokan_seller_wizard_introduction', $this );
    }
}

new Dokan_Setup_Wizard_Override;

/**
 * Delete the images when deleting a product in woocommerce
 */

add_action( 'before_delete_post', function( $id ) {
    $product = wc_get_product( $id );
    if ( ! $product ) {
        return;
    }
    $all_product_ids         = [];
    $product_thum_id_holder  = [];
    $gallery_image_id_holder = [];
    $thum_id                 = get_post_thumbnail_id( $product->get_id() );
    if ( function_exists( 'dokan' ) ) {
        $vendor = dokan()->vendor->get( dokan_get_current_user_id() );
        if ( ! $vendor instanceof WeDevs\Dokan\Vendor\Vendor || $vendor->get_id() === 0 ) {
            return;
        }
        $products = $vendor->get_products();
        if ( empty( $products->posts ) ) {
            return;
        }
        foreach ( $products->posts as $post ) {
            array_push( $all_product_ids, $post->ID );
        }
    } else {
        $args     = [ 'posts_per_page' => '-1' ];
        $products = wc_get_products( $args );
        foreach ( $products as $product ) {
            array_push( $all_product_ids, $product->get_id() );
        }
    }
    foreach ( $all_product_ids as $product_id ) {
        if ( intval( $product_id ) !== intval( $id ) ) {
            array_push( $product_thum_id_holder, get_post_thumbnail_id( $product_id ) );
            $wc_product        = wc_get_product( $product_id );
            $gallery_image_ids = $wc_product->get_gallery_image_ids();
            if ( empty( $gallery_image_ids ) ) {
                continue;
            }
            foreach ( $gallery_image_ids as $gallery_image_id ) {
                array_push( $gallery_image_id_holder, $gallery_image_id );
            }
        }
    }
    if ( ! in_array( $thum_id, $product_thum_id_holder ) && ! in_array( $thum_id, $gallery_image_id_holder ) ) {
        wp_delete_attachment( $thum_id, true );
        if ( empty( $thum_id ) ) {
            return;
        }
        $gallery_image_ids = $product->get_gallery_image_ids();
        if ( empty( $gallery_image_ids ) ) {
            return;
        }
        foreach ( $gallery_image_ids as $gallery_image_id ) {
            wp_delete_attachment( $gallery_image_id, true );
        }
    }
} );

	/**
 * Enable site wide discounts
 */

add_filter( 'dokan_ensure_vendor_coupon', '__return_false' );

	/**
 * Hide communication preferences from 'ShopMagic: Free Follow-Up Emails & Marketing Automation for WooCommerce'
 */

add_filter( 'shopmagic/core/communication_type/account_page_show', '__return_false' );

//New register privacy policy checkbox
add_action( 'woocommerce_register_form', 'bbloomer_add_register_form_privacy_policy', 99 );

function bbloomer_add_register_form_privacy_policy () {
	?>

	<p class="form-row form-group form-row-wide">
            <input class="tc_pp_check_box" type="checkbox" id="tc_agree_pp" name="tc_agree_pp" required="required">
            <label style="display: inline" for="tc_agree_pp"><?php echo wp_kses_post( sprintf( __( 'I have read and agree to the <a target="_blank" href="%s">Privacy Policy</a>.', 'dokan-lite' ), get_privacy_policy_url() ) ); ?></label>
        </p>
        <?php

}

function besa_tbay_change_mini_cart_popup_mobile() {
    return false;
}
add_filter( 'besa_check_cart_is_mobile', 'besa_tbay_change_mini_cart_popup_mobile', 10, 1 );

function dokan_product_field_required_simple(){
?>

<script type="text/javascript">
jQuery(document).ready(function(){
    var product_type = jQuery('select#product_type').val();

    if(product_type == "simple"){
        jQuery('#_regular_price').attr('required', 'required').attr('oninvalid', 'alert(\'Price field is empty\');');
        jQuery('#_weight').attr('required', 'required').attr('oninvalid', 'alert(\'Weight field is empty\');');
    }
});
</script>

<?php
}
add_action('wp_head', 'dokan_product_field_required_simple', 11);