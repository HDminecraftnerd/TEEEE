<?php
/**
 * This file adds the Landing Page Template to the Market Theme.
 *
 * @package      Market
 * @link         http://restored316designs.com/themes
 * @author       Lauren Gaige // Restored 316 LLC
 * @copyright    Copyright (c) 2015, Restored 316 LLC, Released 05/03/2016
 * @license      GPL-2.0+
 */

/*
Template Name: Landing
*/

add_filter( 'body_class', 'market_add_body_class' );
/**
 * Adds landing page body class.
 *
 * @since 1.0.0
 *
 * @param array $classes Original body classes.
 * @return array Modified body classes.
 */
function market_add_body_class( $classes ) {

	$classes[] = 'market-landing';
	return $classes;

}

// Forces full width content layout.
add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );

// Removes site header elements.
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );

// Removes navigation.
remove_action( 'genesis_before_header', 'genesis_do_nav', 7 );
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
remove_action( 'genesis_before_footer', 'market_footer_menu', 7 );

// Removes widget above footer.
remove_action( 'genesis_before_footer', 'market_widget_below_footer', 10 );

// Removes site footer widgets.
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );

// Removes widget above content.
remove_action( 'genesis_after_header', 'market_widget_above_content' );

// Remove site footer elements.
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );

// Runs the Genesis loop.
genesis();
