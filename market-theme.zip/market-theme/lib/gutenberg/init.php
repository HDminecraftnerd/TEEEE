<?php
/**
 * Gutenberg theme support.
 *
 * @package Market
 * @author  Lauren Gaige // Restored 316 LLC
 * @license GPL-2.0-or-later
 * @link    https://www.restored316designs.com/themes
 */

add_action( 'wp_enqueue_scripts', 'market_enqueue_gutenberg_frontend_styles' );
/**
 * Enqueues Gutenberg front-end styles.
 *
 * @since 1.0.2
 */
function market_enqueue_gutenberg_frontend_styles() {

	$child_theme_slug = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'market-theme';

	wp_enqueue_style(
		'market-gutenberg',
		get_stylesheet_directory_uri() . '/lib/gutenberg/front-end.css',
		array( $child_theme_slug ),
		CHILD_THEME_VERSION
	);

}

add_action( 'enqueue_block_editor_assets', 'market_block_editor_styles' );
/**
 * Enqueues Gutenberg admin editor fonts and styles.
 *
 * @since 1.0.2
 */
function market_block_editor_styles() {

	wp_enqueue_style(
		'market-gutenberg-fonts',
		'https://fonts.googleapis.com/css?family=Gentium+Basic:400,400italic|Arimo:400,400italic|IM+Fell+English:400,400italic|EB+Garamond|Homemade+Apple',
		array(),
		CHILD_THEME_VERSION
	);

}

// Adds support for editor styles.
add_theme_support( 'editor-styles' );

// Enqueues editor styles.
add_editor_style( '/lib/gutenberg/style-editor.css' );

// Adds support for block alignments.
add_theme_support( 'align-wide' );

// Makes media embeds responsive.
add_theme_support( 'responsive-embeds' );

// Adds support for editor font sizes.
add_theme_support(
	'editor-font-sizes',
	array(
		array(
			'name'      => __( 'Small', 'market-theme' ),
			'shortName' => __( 'S', 'market-theme' ),
			'size'      => 12,
			'slug'      => 'small',
		),
		array(
			'name'      => __( 'Normal', 'market-theme' ),
			'shortName' => __( 'M', 'market-theme' ),
			'size'      => 16,
			'slug'      => 'normal',
		),
		array(
			'name'      => __( 'Large', 'market-theme' ),
			'shortName' => __( 'L', 'market-theme' ),
			'size'      => 20,
			'slug'      => 'large',
		),
		array(
			'name'      => __( 'Larger', 'market-theme' ),
			'shortName' => __( 'XL', 'market-theme' ),
			'size'      => 24,
			'slug'      => 'larger',
		),
	)
);

add_action( 'after_setup_theme', 'market_content_width', 0 );
/**
 * Sets content width to match the “wide” Gutenberg block width.
 *
 * @since 1.0.2
 */
function market_content_width() {

	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- See https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/924
	$GLOBALS['content_width'] = apply_filters( 'market_content_width', 1200 );

}
